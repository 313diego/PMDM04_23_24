package com.cidead.pmdm.listviewdediegomanuel;

public class Ciudades {
    private int id;
    private String ciudad;
    public Ciudades() {
    }
    public Ciudades(int id, String ciudad) {
        this.id = id;
        this.ciudad = ciudad;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getCiudad() {
        return ciudad;
    }
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    @Override
    public String toString() {
        return ciudad;
    }

}
