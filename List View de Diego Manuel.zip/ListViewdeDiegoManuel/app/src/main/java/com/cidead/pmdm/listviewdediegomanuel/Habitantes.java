package com.cidead.pmdm.listviewdediegomanuel;

public class Habitantes {
    private int id;
    private String habitantes;
    public Habitantes() {
    }
    public Habitantes(int id, String habitantes) {
        this.id = id;
        this.habitantes = habitantes;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getHabitantes() {
        return habitantes;
    }
    public void setHabitantes(String habitantes) {
        this.habitantes = habitantes;
    }
    @Override
    public String toString() {
        return habitantes;
    }

}
