package com.cidead.pmdm.listviewdediegomanuel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);

        lv=(ListView) findViewById(R.id.lvCiudad);
        tv=(TextView) findViewById(R.id.tvHabitantes);

        ArrayList <Ciudades> lista= new ArrayList<Ciudades>();
        lista.add(new Ciudades(1, "Madrid"));
        lista.add(new Ciudades(2,"Barcelona"));
        lista.add(new Ciudades(3, "Valencia"));
        lista.add(new Ciudades(4, "Sevilla"));
        ArrayAdapter<Ciudades>adapter = new ArrayAdapter<Ciudades>(MainActivity.this, android.R.layout.simple_list_item_1,lista);
        lv.setAdapter(adapter);

        ArrayList<Habitantes> hab = new ArrayList<Habitantes>();
        hab.add(new Habitantes(1, " 3.333.931"));
        hab.add(new Habitantes(2, " 1.660.435"));
        hab.add(new Habitantes(3, " 809.501"));
        hab.add(new Habitantes(4, " 693.229"));

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ciudades c = lista.get(position);
                Habitantes h = hab.get(position);
                tv.setText("El número de habitantes de "+c.getCiudad()+": es de"+h.getHabitantes());
            }
        });
    }
}