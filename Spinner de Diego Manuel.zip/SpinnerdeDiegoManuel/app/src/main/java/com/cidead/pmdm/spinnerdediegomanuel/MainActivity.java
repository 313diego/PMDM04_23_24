package com.cidead.pmdm.spinnerdediegomanuel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner sp;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        //Control Spinner y TextView
        sp = (Spinner) findViewById(R.id.spColor);
        tv = (TextView) findViewById(R.id.tvMostrar);

        sp.setOnItemSelectedListener(this);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getItemAtPosition(position).toString().equals("Rojo")){
            tv.setTextColor(getColor(R.color.rojo));
            tv.setText(R.string.rojo_selected);
        }
        if(parent.getItemAtPosition(position).toString().equals("Azul")){
            tv.setTextColor(getColor(R.color.azul));
            tv.setText(R.string.azul_selected);
        }
        if(parent.getItemAtPosition(position).toString().equals("Verde")){
            tv.setTextColor(getColor(R.color.verde));
            tv.setText(R.string.verde_selected);
        }
        if(parent.getItemAtPosition(position).toString().equals("Naranja")){
            tv.setTextColor(getColor(R.color.naranja));
            tv.setText(R.string.naranja_selected);

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        tv.setText(R.string.no_selected);
    }
}